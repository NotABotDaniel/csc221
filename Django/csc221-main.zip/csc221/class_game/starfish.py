class Starfish:
    """This is a starfish. It's evil
    
    Attributes:
        swingStrength (int): how strong the swing attack is
        biteStrength (int): how strong the bite attack is
        life (int): how many hp the Starfish has
        name (str): Every starfish needs a name, right?
        isAlive (bool): Gotta know if it's dead
    """
    
    def __init__(self, starfishName):
        """Creates a Starfish

        Args:
            starfishName (str): Check its birth certificate
        """
        self.swingStrength = random.randint(10,30)
        self.biteStrength = random.randint(10,30)
        self.life = random.randint(100,200)
        self.name = starfishName
        self.isAlive = True
        livingStarfish.append(self)
        print("A new starfish has appeared: ", self.name, ".")
        print("I wonder how strong ",self.name," is???")
    
    def getHurt(self,hp):
        """Get hurt

        Args:
            hp (int): the amount of damage being done
        """
        if not self.isAlive:
            print("You can't attack ",self.name,". They're already dead!")
        elif self.life <= hp:
            print("The attack killed ",self.name,"!")
            self.alive = False
            livingStarfish.remove(self)
            if len(livingStarfish) == 0:
                print("all the Starfish are defeated. You won the game!")
                exit(0)
        else: 
            self.life -= hp
            print("Your attack was successful!")
            time.sleep(1.5)
            print("...but",self.name, " still looks fine")
            time.sleep(1.5)


    def getHealed(self, hp):
        """Called by a healer. Only works if the Starfish isn't already dead

        Args:
            hp (int): How much life will be added
        """
        if not self.isAlive:
            print("You can't heal ",self.name,". They're already dead!")
        else: 
            self.life += hp
            print("The healing spell worked!")
            print(self.name + "'s remaining life is " , self.life)

    def swing(self, target):
        """An attack

        Args:
            target (Dragon | Crab): The Hero we're attacking
        """
        target.getHurt(self.swingStrength)

    def bite(self, target):
        """An attack

        Args:
            target (Dragon): The Dragon we're attacking
        """
        target.getHurt(self.biteStrength)

    def starfishAttack():
        print("-------STARFISH TURN-------")
        
        print("Time for the starfish to strike back")
        #a random vampire will attack a random target
        star = random.choice(livingStarfish)
        target = random.choice(livingHeros)
        time.sleep(1.5)   
        if(random.choice(["swing","bite"]) == "swing"):
            print(star.name, "swings at", target.name)
            time.sleep(1.5)
            target.getHurt(star.swingStrength)
        else:
            print(star.name, "bites", target.name)
            time.sleep(1)
            target.getHurt(star.biteStrength)
        print("-------HERO TURN-------")

