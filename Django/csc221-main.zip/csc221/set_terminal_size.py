import curses
import subprocess

output_pipe = open("/tmp/debug_pipe", "w")


def main(stdscr):
    width = 80
    height = 24

    rows, cols = stdscr.getmaxyx()

    curses.start_color()
    curses.resize_term(height, width)
    subprocess.call(["/usr/bin/size", "-s", str(height), str(width)])

    output_pipe.write("Resized screen to 80x24\n")
    output_pipe.write("lol six seven\n")
    output_pipe.flush()

    stdscr.addstr(6, 32, f"Original window size: {rows} by {cols}")
    stdscr.addstr(11, 32, "Now, This screen is 24x80!")
    stdscr.refresh()

    # clear any output that might have come from resize, and then
    # wait for user to press another key to exit
    curses.flushinp()
    stdscr.getch()


if __name__ == "__main__":
    curses.wrapper(main)

