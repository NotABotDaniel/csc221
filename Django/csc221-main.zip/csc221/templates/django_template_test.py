import django
import os.path
from django.template import Template, Context

#setup Django. Don't mess with these lines
PROJECT_PATH = os.path.realpath(os.path.dirname(__file__))
django.conf.settings.configure(
    TEMPLATES=[{
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [
        os.path.join(PROJECT_PATH),
        ],
    }])
django.setup()

#define your template. 
#these get long, so it's helpful to create it as a separate file
template = django.template.loader.get_template('book_review.html')

#your assignment - add more books
#feeling fancy? add more to your base template.html
context = {'name':"The Hunger Games","past_tense_verb":"ate","num_stars":4}
book = template.render(context)

with open('hunger_games.html', 'w') as f:
    f.write(book)
