from django.db import models
from django.conf import settings


# Create your models here.. this is just an example
class Message(models.Model):
    text = models.CharField(max_length=255, db_index=True)
    sent = models.BooleanField()

    def __str__(self):
        if(self.sent):
            return "You: " + self.text
        else:
            return "Them: " + self.text
