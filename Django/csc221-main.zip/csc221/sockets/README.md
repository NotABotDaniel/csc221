This is a two-way chat app which uses:
- Purses for the front-end
- Python's sockets library for communication
- Django's ORM to save chat history in a Sqlite3 database.

To use:
- Sender and receiver should both checkout this repo
- Initialize the django project:
    - Setup a virtual environment, activate it, and install django:
        - `python3 -m venv .venv`
        - `source .venv/bin/activate`
        - `pip install django`
    -  Create a database based on the models described in `db/models.py`:
        - `python3 manage.py makemigrations db`
        - `python manage.py migrate`
- Run `python3 socket_chat_curses.py`. It will automatically listen on 0.0.0.0 and will randomly choose a port number. Type in your partner's ip address and port number, and start chatting.

To learn more about the django orm code, check out the dedicated repo here: <https://github.com/cj0ne5/django_orm_for_csc221>.

Which heavily borrows from code in Dan Caron's 'Django ORM Standalone project,
here: <https://github.com/dancaron/Django-ORM>. The below copyright notice
comes from that repo.

License
-------

The MIT License (MIT) Copyright (c) 2024 Dan Caron

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
