# socket_server.py
import socket


UDP_IP = "0.0.0.0"
UDP_PORT = int(input("listening port: "))
Partner_IP = input("Parter's IP: ")
Partner_Port = int(input("sending port: "))
receive_first = input("receive first? (y/n): ")=='y'

receive_sock = socket.socket(socket.AF_INET,
                      socket.SOCK_DGRAM)
receive_sock.bind((UDP_IP, UDP_PORT))

sock = socket.socket(socket.AF_INET,
                      socket.SOCK_DGRAM)

#this is the same as the loop below
#just one extra receive if you're receiving first.
if(receive_first):
    data, addr = receive_sock.recvfrom(1024) # buffer size is 1024 bytes
    print(f"them: {data.decode("utf-8")}")


while True:
    MESSAGE = input("you: ").encode()
    sock.sendto(MESSAGE, (Partner_IP, Partner_Port))

    data, addr = receive_sock.recvfrom(1024) # buffer size is 1024 bytes
    print(f"them: {data.decode("utf-8")}")

