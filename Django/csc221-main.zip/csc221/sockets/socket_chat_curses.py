import socket
import curses
import random

def setup_sockets():
    #Initialize Chat Sockets.
    #This code runs before curses starts, so we can use input()
    UDP_IP = "0.0.0.0"
    UDP_PORT = random.randint(8000,8999)
    
    print(f"I'm listening on {UDP_IP}:{UDP_PORT}")
    Partner_IP = input("Parter's IP (127.0.0.1): ")
    if(Partner_IP == ""): Partner_IP = "127.0.0.1"
    Partner_Port = int(input("sending port: "))

    receive_sock = socket.socket(socket.AF_INET,
                        socket.SOCK_DGRAM)
    receive_sock.bind((UDP_IP, UDP_PORT))

    send_sock = socket.socket(socket.AF_INET,
                        socket.SOCK_DGRAM)

    #return - both sockets and a tuple that represents the partner
    return (send_sock, receive_sock, (Partner_IP, Partner_Port))


def setup_curses(stdscr):
    # Initialize Curses 
    curses.echo() #make the input visible
    height, width = (24,80) #we're hard-coding this for now. 
                            #make sure you manually adjust to 24x80 
                            #before running

    
    # Create a window to display the chat history
    chat_height = height-3
    chat_win = curses.newwin(chat_height, width, 0, 0)
    
    # Create a window to type and read input
    input_win = curses.newwin(3, width, chat_height, 0)
    input_win.border()
    input_win.addstr(1, 2, "> ")
    input_win.refresh()

    return (input_win, chat_win)


def input_message(input_win):
    # Show user input
    width = 80 #todo - find a way to not hardcode this

    #clear any previous message in the input area
    input_win.addstr(1, 4, " " * (width - 5))
    curses.echo()


    #getstr moves the cursor to position (1,4) relative to this window,
    #  waits for the user to hit the enter key,
    # and then returns whatever the user typed.
    user_input = input_win.getstr(1, 4, width - 5).decode('utf-8').strip()

    #turn off user input until we're done updating the screen
    curses.noecho()
    
    if user_input:
        input_win.addstr(1, 4, " " * (width - 5))
        input_win.refresh()
        return user_input

def receive_message(receive_sock, input_win):
    width = 80 #TODO: don't hard-code this
    input_win.addstr(1, 4, "Waiting to Receive" + " " * (width - 5 - 18))
    input_win.refresh()
    data, addr = receive_sock.recvfrom(1024) # buffer size is 1024 bytes

    return data.decode("utf-8")

def write_chat_history(chat_win,messages):
    # This function erases the entire history screen
    # and re-writes it. There's probably a more efficient way..

    chat_height = 21 #TODO: DOn't hard-code this.
    chat_win.erase()
    for i, msg in enumerate(messages[-chat_height:]):
        chat_win.addstr(i, 0, msg)
    chat_win.refresh()

def read_chat_history_from_db():
    messages = []
    for m in Message.objects.all():
        messages.append(str(m))
    return messages

def main(stdscr, send_sock, receive_sock, receive_first, partner):
    #usually main just takes in stdscr for curses. i'm also 
    #passing in all the information collected from before curses starts

    #I'm trying to avoid using global variables here, so there's a 
    #lot of info being passed into/returned from each of these functions

    input_win, chat_win = setup_curses(stdscr)

    #while the program is running, messages is just a list of strings.
    #initialize it from the db
    messages = read_chat_history_from_db()
    write_chat_history(chat_win, messages)

    #main loop: send, receive, send, receive
    if(receive_first):
        message_received = receive_message(receive_sock,input_win)
        messages.append(f"Them: {message_received}")
        Message.objects.create(text=message_received, sent=False)
        write_chat_history(chat_win,messages)

    while True:
        #send
        message_to_send = input_message(input_win)
        messages.append(f"You: {message_to_send}")
        Message.objects.create(text=message_to_send, sent=True)
        send_sock.sendto(message_to_send.encode(), partner)
        write_chat_history(chat_win,messages)
        
        #receive
        message_received = receive_message(receive_sock,input_win) 
        messages.append(f"Them: {message_received}")
        Message.objects.create(text=message_received, sent=False)
        write_chat_history(chat_win,messages)

if __name__ == "__main__":
    ############################################################################
    ## Django ORM Standalone Python Template
    ############################################################################
    """ Here we'll import the parts of Django we need. It's recommended to leave
    these settings as is, and skip to START OF APPLICATION section below """

    # Turn off bytecode generation
    import sys
    sys.dont_write_bytecode = True

    # Import settings
    import os
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'orm.settings')

    # setup django environment
    import django
    django.setup()

    # Import your models for use in your script
    from db.models import *

    ############################################################################
    ## START OF APPLICATION
    ############################################################################
    #handle some user input before we initialze curses
    send_sock, receive_sock, partner = setup_sockets()
    receive_first = input("receive first? (y/n): ")=='y'
    curses.wrapper(main, send_sock, receive_sock, receive_first, partner)

