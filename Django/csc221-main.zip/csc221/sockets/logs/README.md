This directory contains logs of sql commands that Django runs.
That file is called debug.log and is gitignored, so it won't appear
in this repo. This README file only exists because git won't track empty
directories.