import curses
from curses import wrapper


def main(stdscr):
    stdscr.clear()
    stdscr.addstr(23,60, "Hello CSC 221!")
    stdscr.refresh()
    stdscr.getch()


wrapper(main)

